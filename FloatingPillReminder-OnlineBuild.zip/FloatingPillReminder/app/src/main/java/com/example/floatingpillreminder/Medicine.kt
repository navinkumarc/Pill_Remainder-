package com.example.floatingpillreminder

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dose: String,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean = true
)
