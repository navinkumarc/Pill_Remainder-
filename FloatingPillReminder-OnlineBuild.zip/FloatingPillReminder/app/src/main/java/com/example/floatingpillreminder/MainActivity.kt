package com.example.floatingpillreminder

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private val db by lazy { AppDatabase.get(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "💊 Floating Pill Reminder"
            textSize = 24f
        })
        root.addView(TextView(this).apply {
            text = "Add daily medicines and enable the floating pill."
            textSize = 14f
            setPadding(0, 12, 0, 20)
        })
        val name = EditText(this).apply { hint = "Medicine name (e.g. Tablet A)" }
        val dose = EditText(this).apply { hint = "Dose (e.g. 1 tablet)" }
        root.addView(name)
        root.addView(dose)
        var hour = 9
        var minute = 0
        val time = Button(this).apply { text = "Reminder time: 09:00 AM" }
        time.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                hour = h; minute = m
                time.text = String.format("Reminder time: %02d:%02d", h, m)
            }, hour, minute, false).show()
        }
        root.addView(time)
        root.addView(Button(this).apply {
            text = "Add medicine"
            setOnClickListener {
                val n = name.text.toString().trim()
                val d = dose.text.toString().trim()
                if (n.isBlank()) { name.error = "Enter medicine name"; return@setOnClickListener }
                Thread {
                    val medicine = Medicine(name = n, dose = d, hour = hour, minute = minute)
                    val id = db.medicineDao().insert(medicine)
                    AlarmScheduler.schedule(this, medicine.copy(id = id))
                    runOnUiThread {
                        name.text.clear(); dose.text.clear()
                        Toast.makeText(this, "Medicine saved and reminder scheduled", Toast.LENGTH_SHORT).show()
                        loadMedicines()
                    }
                }.start()
            }
        })
        root.addView(Button(this).apply {
            text = "Enable floating pill"
            setOnClickListener { enableFloating() }
        })
        root.addView(Button(this).apply {
            text = "Stop floating pill"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "Your medicines"
            textSize = 20f
            setPadding(0, 24, 0, 8)
        })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(root)
        loadMedicines()
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")), 40
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            }
        }
        val i = Intent(this, FloatingService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Floating pill enabled", Toast.LENGTH_SHORT).show()
    }

    private fun loadMedicines() {
        Thread {
            val medicines = db.medicineDao().getAll()
            runOnUiThread {
                list.removeAllViews()
                medicines.forEach { med ->
                    val row = TextView(this).apply {
                        text = "• ${med.name} — ${med.dose} at %02d:%02d".format(med.hour, med.minute)
                        textSize = 16f
                        setPadding(0, 8, 0, 8)
                    }
                    list.addView(row)
                }
                if (medicines.isEmpty()) list.addView(TextView(this).apply { text = "No medicines added yet." })
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 40 && Settings.canDrawOverlays(this)) enableFloating()
    }
}
