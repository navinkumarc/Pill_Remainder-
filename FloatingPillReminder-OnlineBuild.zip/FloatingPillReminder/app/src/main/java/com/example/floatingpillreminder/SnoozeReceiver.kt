package com.example.floatingpillreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class SnoozeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("medicine_id", 0L)
        val again = Intent(context, AlarmReceiver::class.java).apply {
            putExtra("medicine_id", id)
            putExtra("medicine_name", intent.getStringExtra("medicine_name"))
            putExtra("medicine_dose", intent.getStringExtra("medicine_dose"))
        }
        val pending = PendingIntent.getBroadcast(
            context, 10000 + id.toInt(), again,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = System.currentTimeMillis() + 10 * 60 * 1000
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pending)
    }
}
