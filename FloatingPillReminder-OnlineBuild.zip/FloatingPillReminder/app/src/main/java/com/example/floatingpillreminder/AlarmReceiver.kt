package com.example.floatingpillreminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("medicine_id", -1L)
        val name = intent.getStringExtra("medicine_name") ?: "Your medicine"
        val dose = intent.getStringExtra("medicine_dose") ?: ""
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("medicine_due", "Medicine reminders", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val open = PendingIntent.getActivity(
            context, 700, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snooze = PendingIntent.getBroadcast(
            context, 800 + id.toInt(),
            Intent(context, SnoozeReceiver::class.java).putExtra("medicine_id", id)
                .putExtra("medicine_name", name).putExtra("medicine_dose", dose),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "medicine_due")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Time to take $name")
            .setContentText(dose)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(0, "Snooze 10 min", snooze)
            .build()
        nm.notify(id.toInt(), notification)

        // Schedule the next daily occurrence.
        Thread {
            AppDatabase.get(context).medicineDao().getById(id)?.let {
                AlarmScheduler.schedule(context, it)
            }
        }.start()

        // If the user has already enabled the overlay service, refresh its reminder content.
        val update = Intent(context, FloatingService::class.java).apply {
            action = FloatingService.ACTION_SHOW_DOSE
            putExtra("medicine_id", id)
            putExtra("medicine_name", name)
            putExtra("medicine_dose", dose)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(update)
            else context.startService(update)
        } catch (_: Exception) {
            // The notification remains available if Android blocks background service start.
        }
    }
}
