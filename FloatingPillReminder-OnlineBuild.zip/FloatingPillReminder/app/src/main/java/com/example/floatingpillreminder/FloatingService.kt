package com.example.floatingpillreminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var expanded = false
    private var label = "💊 Floating reminder"
    private var detail = "Tap to open your medicines"
    private var activeMedicineId: Long = -1L
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        startForeground(91, serviceNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Settings.canDrawOverlays(this)) showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_DOSE) {
            activeMedicineId = intent.getLongExtra("medicine_id", -1L)
            label = "💊 " + (intent.getStringExtra("medicine_name") ?: "Medicine due")
            detail = intent.getStringExtra("medicine_dose") ?: "Time to take your medicine"
            refreshBubble()
        }
        if (bubble == null && Settings.canDrawOverlays(this)) showBubble()
        return START_STICKY
    }

    private fun serviceNotification(): Notification {
        val channel = "floating_service"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(channel, "Floating pill service", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Floating Pill Reminder is active")
            .setContentText("Your floating medicine shortcut is enabled")
            .setOngoing(true)
            .build()
    }

    private fun showBubble() {
        if (bubble != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 14, 22, 14)
            setBackgroundColor(0xEE17365D.toInt())
        }
        val title = TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val sub = TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(0xFFE5E7EB.toInt())
            visibility = View.GONE
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        val taken = TextView(this).apply {
            text = "  Taken ✓  "
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 12, 8, 8)
            setOnClickListener {
                if (activeMedicineId > 0) Thread {
                    AppDatabase.get(this@FloatingService).medicineDao().insertHistory(
                        DoseHistory(activeMedicineId, label.removePrefix("💊 "), "TAKEN")
                    )
                }.start()
                detail = "Marked taken"
                sub.text = detail
                collapse(root, sub, actions)
            }
        }
        val snooze = TextView(this).apply {
            text = "  Snooze 10m  "
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 12, 8, 8)
            setOnClickListener {
                val snoozeIntent = Intent(this@FloatingService, SnoozeReceiver::class.java).apply {
                    putExtra("medicine_id", activeMedicineId)
                    putExtra("medicine_name", label.removePrefix("💊 "))
                    putExtra("medicine_dose", detail)
                }
                val pi = android.app.PendingIntent.getBroadcast(
                    this@FloatingService, 20000 + activeMedicineId.toInt(), snoozeIntent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                )
                val alarm = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
                val at = System.currentTimeMillis() + 10 * 60 * 1000
                if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(
                    android.app.AlarmManager.RTC_WAKEUP, at, pi
                ) else alarm.setExact(android.app.AlarmManager.RTC_WAKEUP, at, pi)
                if (activeMedicineId > 0) Thread {
                    AppDatabase.get(this@FloatingService).medicineDao().insertHistory(
                        DoseHistory(activeMedicineId, label.removePrefix("💊 "), "SNOOZED")
                    )
                }.start()
                detail = "Snoozed for 10 minutes"
                sub.text = detail
                collapse(root, sub, actions)
            }
        }
        actions.addView(taken)
        actions.addView(snooze)
        root.addView(title)
        root.addView(sub)
        root.addView(actions)

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 220
        }
        var downX = 0
        var downY = 0
        var startX = 0
        var startY = 0
        var moved = false
        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX.toInt(); downY = event.rawY.toInt()
                    startX = params.x; startY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX.toInt() - downX
                    val dy = event.rawY.toInt() - downY
                    if (abs(dx) + abs(dy) > 12) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        expanded = !expanded
                        sub.visibility = if (expanded) View.VISIBLE else View.GONE
                        actions.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }
        bubble = root
        try { wm.addView(root, params) } catch (_: Exception) { bubble = null }
    }

    private fun collapse(root: View, sub: TextView, actions: LinearLayout) {
        expanded = false
        sub.visibility = View.GONE
        actions.visibility = View.GONE
    }

    private fun refreshBubble() {
        val old = bubble
        if (old != null) {
            try { wm.removeView(old) } catch (_: Exception) {}
            bubble = null
        }
        if (Settings.canDrawOverlays(this)) showBubble()
    }

    override fun onDestroy() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_SHOW_DOSE = "com.example.floatingpillreminder.SHOW_DOSE"
    }
}
