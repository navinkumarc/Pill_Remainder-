package com.example.floatingpillreminder

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines ORDER BY hour, minute")
    fun getAll(): List<Medicine>
    @Query("SELECT * FROM medicines WHERE id = :id LIMIT 1")
    fun getById(id: Long): Medicine?
    @Insert
    fun insert(medicine: Medicine): Long
    @Delete
    fun delete(medicine: Medicine)
    @Query("SELECT * FROM medicines WHERE enabled = 1")
    fun getEnabled(): List<Medicine>
    @Insert
    fun insertHistory(item: DoseHistory)
    @Query("SELECT * FROM dose_history ORDER BY recordedAt DESC LIMIT 100")
    fun getHistory(): List<DoseHistory>
}
