# Floating Pill Reminder (Android)

A starter native Android project for a personal, offline medication reminder with:
- Room database for medicine schedules
- Daily exact alarm scheduling
- Notifications with a 10-minute snooze action
- Draggable floating overlay window
- Taken and snooze UI actions in the floating bubble
- Boot receiver to reschedule daily alarms
- GitHub Actions workflow to build a debug APK online

## Build online (no Android Studio required)

1. Create a new **public or private** GitHub repository.
2. Upload the contents of this ZIP (not the ZIP itself) to the repository root.
3. Commit to the `main` branch.
4. Open **Actions** in GitHub. The workflow `Build Floating Pill Reminder APK` runs on push.
5. Open the successful run and download the `FloatingPillReminder-debug-apk` artifact.
6. Extract the ZIP and install `app-debug.apk` on your Android phone.

You can also run the workflow manually from Actions → Build Floating Pill Reminder APK → Run workflow.

## First-time phone setup

1. Install and open the app.
2. Tap **Enable floating pill**.
3. Allow **Display over other apps**.
4. Allow notifications when prompted.
5. Allow exact alarms if Android opens that settings page.
6. On iQOO, open Settings and allow the app's background/autostart operation if those options are available on your Funtouch OS version.
7. Add a medicine and test with a time a few minutes ahead.

## Important limitations of this starter version

- This is a starter project, not a certified medical device or a substitute for a prescribed medication plan.
- The floating bubble is user-enabled and draggable. It can be expanded by tapping it.
- The floating Taken and Snooze actions record a simple event in the local dose-history table; Snooze schedules a reminder 10 minutes later.
- This starter does not yet provide a dedicated history screen, medicine editing/deletion, multiple daily times per medicine, or a full adherence analytics view.
- Daily medicine reminders are scheduled. Multiple times per day, weekdays, editing/deleting medicines, adherence history, and dose-specific confirmation still need further development.
- Android and iQOO battery/background policies can stop background work. A user force-stop prevents alarms/receivers until the app is opened again. Test after reboot, battery saver, and screen-off.
- Exact alarms require user permission on applicable Android versions. If permission is denied, punctual delivery cannot be guaranteed.
- This project builds a **debug APK**. For long-term distribution, create a signed release build and protect the signing key.

## Technical details

- Kotlin, Android Views, Room, AlarmManager, NotificationCompat
- minSdk 26, targetSdk 35
- GitHub Actions builds with JDK 17 and Gradle 8.9

## Safety

Only enter medicines and schedules prescribed or confirmed by your clinician/pharmacist. Do not change dose or timing based on this app.
